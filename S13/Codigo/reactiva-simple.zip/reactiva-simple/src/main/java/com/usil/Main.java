package com.usil;

import com.usil.controller.EstudianteController;
import com.usil.service.EstudianteService;
import com.usil.view.VentanaEstudiantes;
import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            EstudianteService servicio = new EstudianteService();
            EstudianteController controlador = new EstudianteController(servicio);
            new VentanaEstudiantes(controlador).setVisible(true);
        });
    }
}
