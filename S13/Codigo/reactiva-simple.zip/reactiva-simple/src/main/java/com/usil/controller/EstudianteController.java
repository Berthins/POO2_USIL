package com.usil.controller;

import com.usil.model.Estudiante;
import com.usil.service.EstudianteService;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/** CONTROLLER: solo trabaja con el service. La vista lo llama a él. */
public class EstudianteController {

    private final EstudianteService servicio;

    public EstudianteController(EstudianteService servicio) {
        this.servicio = servicio;
    }

    public Mono<Estudiante> registrar(String nombre, String nota) {
        try {
            return servicio.registrar(nombre.trim(), Double.parseDouble(nota.trim()));
        } catch (NumberFormatException e) {
            return Mono.error(new IllegalArgumentException("La nota debe ser un número"));
        }
    }

    public Flux<Estudiante> listar() {
        return servicio.listar();
    }

    public Flux<String> notificaciones() {
        return servicio.notificaciones();
    }

    public Flux<Double> promedioEnVivo() {
        return servicio.promedioEnVivo();
    }

    public Mono<Estudiante> buscar(String id) {
        try {
            return servicio.buscar(Integer.parseInt(id.trim()));
        } catch (NumberFormatException e) {
            return Mono.error(new IllegalArgumentException("El ID debe ser un número"));
        }
    }
}
