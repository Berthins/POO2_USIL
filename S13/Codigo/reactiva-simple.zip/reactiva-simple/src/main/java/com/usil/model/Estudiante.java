package com.usil.model;

/** MODELO: solo guarda datos. */
public class Estudiante {

    private int id;
    private String nombre;
    private double nota;

    public Estudiante(int id, String nombre, double nota) {
        this.id = id;
        this.nombre = nombre;
        this.nota = nota;
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public double getNota() { return nota; }

    @Override
    public String toString() {
        return "#" + id + " " + nombre + " - nota: " + nota;
    }
}
