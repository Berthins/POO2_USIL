package com.usil.service;

import com.usil.model.Estudiante;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.publisher.Sinks;

/**
 * SERVICE: la lógica. No conoce al controller ni a la vista.
 *   Mono = 0 ó 1 resultado
 *   Flux = 0 a N resultados
 */
public class EstudianteService {

    private final List<Estudiante> estudiantes = new CopyOnWriteArrayList<>();
    private int siguienteId = 1;

    // Canal: cada estudiante que se registra se "empuja" aquí y quien esté suscrito lo recibe.
    private final Sinks.Many<Estudiante> canal = Sinks.many().multicast().directBestEffort();

    /** MONO asíncrono: valida al instante y guarda 2 segundos DESPUÉS, sin bloquear nada. */
    public Mono<Estudiante> registrar(String nombre, double nota) {
        if (nombre == null || nombre.isBlank()) {
            return Mono.error(new IllegalArgumentException("El nombre es obligatorio"));
        }
        if (nota < 0 || nota > 20) {
            return Mono.error(new IllegalArgumentException("La nota debe estar entre 0 y 20"));
        }
        return Mono.fromCallable(() -> guardar(nombre, nota))
                .delaySubscription(Duration.ofSeconds(2)); // simula una base de datos lenta
    }

    private synchronized Estudiante guardar(String nombre, double nota) {
        Estudiante nuevo = new Estudiante(siguienteId++, nombre, nota);
        estudiantes.add(nuevo);
        canal.tryEmitNext(nuevo); // avisa a todos los suscritos
        return nuevo;
    }

    /** FLUX en vivo: un mensaje por cada estudiante registrado (nunca termina, queda escuchando). */
    public Flux<String> notificaciones() {
        return canal.asFlux().map(e -> "Nuevo estudiante registrado: " + e.getNombre());
    }

    /** FLUX en vivo: el promedio se recalcula solo cada vez que llega un registro. */
    public Flux<Double> promedioEnVivo() {
        return canal.asFlux().map(e ->
                estudiantes.stream().mapToDouble(Estudiante::getNota).
                        average().orElse(0));
    }

    /** FLUX: devuelve todos los estudiantes. */
    public Flux<Estudiante> listar() {
        return Flux.fromIterable(estudiantes);
    }

    /** MONO: devuelve 1 estudiante, o error si no existe. */
    public Mono<Estudiante> buscar(int id) {
        return Flux.fromIterable(estudiantes)
                .filter(e -> e.getId() == id)
                .next()
                .switchIfEmpty(Mono.error(new RuntimeException("No existe estudiante con ID " + id)));
    }
}
