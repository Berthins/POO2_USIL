package com.usil.view;

import com.usil.controller.EstudianteController;
import javax.swing.SwingUtilities;

/**
 * VIEW (JFrame Form): se edita en la pestaña "Design" de NetBeans.
 * Solo trabaja con el controller.
 */
public class VentanaEstudiantes extends javax.swing.JFrame {

    private final EstudianteController controlador;

    public VentanaEstudiantes(EstudianteController controlador) {
        this.controlador = controlador;
        initComponents();
        // Flux en vivo: cada mensaje que llegue se muestra en la etiqueta.
        // invokeLater porque el mensaje llega desde otro hilo y Swing solo se toca desde el suyo.
        controlador.notificaciones().subscribe(mensaje ->
                SwingUtilities.invokeLater(() -> lblNotificacion.setText(mensaje)));
        // Flux en vivo: el promedio se actualiza solo.
        controlador.promedioEnVivo().subscribe(promedio ->
                SwingUtilities.invokeLater(() -> lblPromedio.setText(String.format("Promedio: %.2f", promedio))));
        setSize(950, 350);
        setLocationRelativeTo(null);
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelSuperior = new javax.swing.JPanel();
        lblNombre = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        lblNota = new javax.swing.JLabel();
        lblNotificacion = new javax.swing.JLabel();
        lblPromedio = new javax.swing.JLabel();
        txtNota = new javax.swing.JTextField();
        btnRegistrar = new javax.swing.JButton();
        btnListar = new javax.swing.JButton();
        lblId = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        areaResultado = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Mono y Flux - ejemplo simple");

        lblNombre.setText("Nombre:");
        panelSuperior.add(lblNombre);

        txtNombre.setColumns(10);
        panelSuperior.add(txtNombre);

        lblNota.setText("Nota:");
        panelSuperior.add(lblNota);

        txtNota.setColumns(4);
        panelSuperior.add(txtNota);

        btnRegistrar.setText("Registrar");
        btnRegistrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegistrarActionPerformed(evt);
            }
        });
        panelSuperior.add(btnRegistrar);

        btnListar.setText("Listar");
        btnListar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnListarActionPerformed(evt);
            }
        });
        panelSuperior.add(btnListar);

        lblId.setText("ID:");
        panelSuperior.add(lblId);

        txtId.setColumns(4);
        panelSuperior.add(txtId);

        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });
        panelSuperior.add(btnBuscar);

        lblPromedio.setText("Promedio: --");
        panelSuperior.add(lblPromedio);

        getContentPane().add(panelSuperior, java.awt.BorderLayout.NORTH);

        areaResultado.setEditable(false);
        areaResultado.setColumns(20);
        areaResultado.setRows(5);
        jScrollPane1.setViewportView(areaResultado);

        getContentPane().add(jScrollPane1, java.awt.BorderLayout.CENTER);

        lblNotificacion.setText("Notificaciones: ninguna");
        getContentPane().add(lblNotificacion, java.awt.BorderLayout.SOUTH);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistrarActionPerformed
        mostrar("Registrando... (tarda 2 segundos, la ventana sigue libre)");
        // Mono asíncrono: el resultado llega 2 segundos después, desde otro hilo
        controlador.registrar(txtNombre.getText(), txtNota.getText()).subscribe(
                est -> {
                    mostrar("Registrado: " + est);
                    SwingUtilities.invokeLater(() -> {
                        txtNombre.setText("");
                        txtNota.setText("");
                    });
                },
                error -> mostrar("Error: " + error.getMessage()));
    }//GEN-LAST:event_btnRegistrarActionPerformed

    private void btnListarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnListarActionPerformed
        areaResultado.setText("");
        // Flux: la lambda se ejecuta una vez por cada estudiante
        controlador.listar().subscribe(est -> mostrar(est.toString()));
    }//GEN-LAST:event_btnListarActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        areaResultado.setText("");
        // Mono: 1 resultado o error si no existe
        controlador.buscar(txtId.getText()).subscribe(
                est -> mostrar("Encontrado: " + est),
                error -> mostrar("Error: " + error.getMessage()));
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void mostrar(String texto) {
        SwingUtilities.invokeLater(() -> areaResultado.append(texto + "\n"));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea areaResultado;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnListar;
    private javax.swing.JButton btnRegistrar;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblId;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblNota;
    private javax.swing.JLabel lblNotificacion;
    private javax.swing.JLabel lblPromedio;
    private javax.swing.JPanel panelSuperior;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtNota;
    // End of variables declaration//GEN-END:variables
}
