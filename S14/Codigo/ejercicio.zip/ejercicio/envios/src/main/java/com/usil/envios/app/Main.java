package com.usil.envios.app;

import com.usil.envios.controller.EnvioController;
import com.usil.envios.repository.EnvioRepository;
import com.usil.envios.service.EnvioService;
import com.usil.envios.vista.VistaConsola;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;

public class Main {

    public static void main(String[] args) {
        System.setOut(new PrintStream(System.out, true, StandardCharsets.UTF_8)); // tildes en la consola
        EnvioService service = new EnvioService(new EnvioRepository());
        EnvioController controller = new EnvioController(service);
        new VistaConsola(controller).iniciar();
    }
}
