package com.usil.envios.builder;

import com.usil.envios.model.Envio;

// Patrón Builder: construye el Envio paso a paso (interfaz fluida).
public class EnvioBuilder {

    private String id;
    private String destinatario;
    private double peso;
    private String destino;
    private String descripcion;

    public EnvioBuilder id(String id) {
        this.id = id;
        return this;
    }

    public EnvioBuilder destinatario(String destinatario) {
        this.destinatario = destinatario;
        return this;
    }

    public EnvioBuilder peso(double peso) {
        this.peso = peso;
        return this;
    }

    public EnvioBuilder destino(String destino) {
        this.destino = destino;
        return this;
    }

    public EnvioBuilder descripcion(String descripcion) {
        this.descripcion = descripcion;
        return this;
    }

    public Envio build() {
        if (peso <= 0) {
            throw new IllegalStateException("el peso debe ser mayor a 0");
        }
        obligatorio(id, "id");
        obligatorio(destinatario, "destinatario");
        obligatorio(destino, "destino");
        obligatorio(descripcion, "descripcion");
        return new Envio(id, destinatario, peso, destino, descripcion);
    }

    private void obligatorio(String valor, String campo) {
        if (valor == null || valor.isBlank()) {
            throw new IllegalStateException("el campo " + campo + " es obligatorio");
        }
    }
}
