package com.usil.envios.controller;

import com.usil.envios.builder.EnvioBuilder;
import com.usil.envios.model.Envio;
import com.usil.envios.model.EstadoEnvio;
import com.usil.envios.reactivo.ReporteEnvios;
import com.usil.envios.service.EnvioService;
import com.usil.envios.strategy.NotificadorCorreo;
import com.usil.envios.strategy.NotificadorSms;
import java.util.List;

// Une la vista con el servicio.
public class EnvioController {

    private final EnvioService service;
    private final ReporteEnvios reporte = new ReporteEnvios();

    public EnvioController(EnvioService service) {
        this.service = service;
    }

    // Construye el envío con el Builder, lo guarda y devuelve la notificación enviada.
    public String registrarEnvio(String id, String destinatario, double peso, String destino, String descripcion) {
        Envio envio = new EnvioBuilder()
                .id(id)
                .destinatario(destinatario)
                .peso(peso)
                .destino(destino)
                .descripcion(descripcion)
                .build();
        return service.registrar(envio);
    }

    public List<Envio> listarEnvios() {
        return service.listar();
    }

    public long contarEntregados() {
        return service.contarEntregados();
    }

    public String avanzarEstado(String id) {
        return service.avanzarEstado(id);
    }

    public EstadoEnvio estadoDe(String id) {
        return service.estadoDe(id);
    }

    public void cancelarEnvio(String id) {
        service.cancelar(id);
    }

    public void cambiarCanal(int opcion) {
        if (opcion == 1) {
            service.cambiarNotificador(new NotificadorCorreo());
        } else if (opcion == 2) {
            service.cambiarNotificador(new NotificadorSms());
        } else {
            throw new IllegalStateException("el canal elegido no existe");
        }
    }

    public String nombreCanal() {
        return service.getNotificador().getNombre();
    }

    public void mostrarPendientesMasPesados(int cantidad) {
        reporte.mostrarPendientesMasPesados(service.listar(), cantidad);
    }
}
