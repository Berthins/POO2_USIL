package com.usil.envios.model;

public class Envio {

    private final String id;
    private final String destinatario;
    private final double peso;
    private final String destino;
    private final String descripcion;
    private EstadoEnvio estado = EstadoEnvio.REGISTRADO; // todo envío nace REGISTRADO

    public Envio(String id, String destinatario, double peso, String destino, String descripcion) {
        this.id = id;
        this.destinatario = destinatario;
        this.peso = peso;
        this.destino = destino;
        this.descripcion = descripcion;
    }

    public String getId() {
        return id;
    }

    public String getDestinatario() {
        return destinatario;
    }

    public double getPeso() {
        return peso;
    }

    public String getDestino() {
        return destino;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public EstadoEnvio getEstado() {
        return estado;
    }

    public void setEstado(EstadoEnvio estado) {
        this.estado = estado;
    }
}
