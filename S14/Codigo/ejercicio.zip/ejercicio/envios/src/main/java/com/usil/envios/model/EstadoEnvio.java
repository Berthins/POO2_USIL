package com.usil.envios.model;

public enum EstadoEnvio {
    REGISTRADO, EN_RUTA, ENTREGADO;

    // Siguiente estado del recorrido; ENTREGADO es el final.
    public EstadoEnvio siguiente() {
        return switch (this) {
            case REGISTRADO -> EN_RUTA;
            case EN_RUTA, ENTREGADO -> ENTREGADO;
        };
    }

    public String etiqueta() {
        return name().replace('_', ' ');
    }
}
