package com.usil.envios.reactivo;

import com.usil.envios.model.Envio;
import com.usil.envios.model.EstadoEnvio;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import reactor.core.publisher.Flux;

// Programación reactiva: los envíos se tratan como un flujo (Flux).
public class ReporteEnvios {

    public void mostrarPendientesMasPesados(List<Envio> envios, int cantidad) {
        Flux<Envio> pendientes = Flux.fromIterable(envios)                       // la lista se convierte en un flujo
                .filter(envio -> envio.getEstado() != EstadoEnvio.ENTREGADO)     // solo los envíos pendientes
                .sort(Comparator.comparingDouble(Envio::getPeso).reversed())     // de mayor a menor peso
                .take(cantidad);                                                 // solo los primeros

        pendientes.map(envio -> envio.getId() + " | " + envio.getDestinatario() + " | "
                        + String.format(Locale.US, "%.2f kg", envio.getPeso()))  // cada envío pasa a texto
                .subscribe(System.out::println);

        pendientes.map(Envio::getPeso)                                           // el mismo flujo suma los pesos
                .reduce(0.0, Double::sum)
                .subscribe(total -> System.out.println(
                        "Peso a despachar: " + String.format(Locale.US, "%.2f kg", total)));
    }
}
