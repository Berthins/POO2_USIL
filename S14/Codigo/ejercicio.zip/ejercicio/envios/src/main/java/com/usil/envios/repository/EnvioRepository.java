package com.usil.envios.repository;

import com.usil.envios.model.Envio;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

// Guarda los envíos en memoria, en orden de registro.
public class EnvioRepository implements Repository<Envio, String> {

    private final Map<String, Envio> envios = new LinkedHashMap<>();

    @Override
    public void crear(Envio envio) {
        if (envios.containsKey(envio.getId())) {
            throw new IllegalStateException("ya existe un envío con el id " + envio.getId());
        }
        envios.put(envio.getId(), envio);
    }

    @Override
    public Optional<Envio> buscarPorId(String id) {
        return Optional.ofNullable(envios.get(id));
    }

    @Override
    public List<Envio> listar() {
        return new ArrayList<>(envios.values());
    }

    @Override
    public void actualizar(Envio envio) {
        if (!envios.containsKey(envio.getId())) {
            throw new IllegalStateException("no existe un envío con el id " + envio.getId());
        }
        envios.put(envio.getId(), envio);
    }

    @Override
    public void eliminar(String id) {
        if (!envios.containsKey(id)) {
            throw new IllegalStateException("no existe un envío con el id " + id);
        }
        envios.remove(id);
    }
}
