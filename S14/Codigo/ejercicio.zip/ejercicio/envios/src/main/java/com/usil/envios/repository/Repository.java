package com.usil.envios.repository;

import java.util.List;
import java.util.Optional;

// Patrón Repository: repositorio genérico con las operaciones CRUD.
// T = tipo de entidad, ID = tipo del identificador.
public interface Repository<T, ID> {

    void crear(T entidad);

    Optional<T> buscarPorId(ID id);

    List<T> listar();

    void actualizar(T entidad);

    void eliminar(ID id);
}
