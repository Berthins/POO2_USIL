package com.usil.envios.service;

import com.usil.envios.model.Envio;
import com.usil.envios.model.EstadoEnvio;
import com.usil.envios.repository.Repository;
import com.usil.envios.strategy.NotificadorCorreo;
import com.usil.envios.strategy.NotificadorEnvio;
import java.util.List;

public class EnvioService {

    private final Repository<Envio, String> repositorio;
    private NotificadorEnvio notificador = new NotificadorCorreo();

    public EnvioService(Repository<Envio, String> repositorio) {
        this.repositorio = repositorio;
    }

    // Guarda el envío y devuelve el mensaje que el canal activo envía al destinatario.
    public String registrar(Envio envio) {
        repositorio.crear(envio);
        return notificador.mensaje(envio);
    }

    public List<Envio> listar() {
        return repositorio.listar();
    }

    // Cantidad de envíos entregados, con Streams.
    public long contarEntregados() {
        return repositorio.listar().stream()
                .filter(e -> e.getEstado() == EstadoEnvio.ENTREGADO)
                .count();
    }

    // Avanza el estado (REGISTRADO -> EN_RUTA -> ENTREGADO) y devuelve la notificación.
    public String avanzarEstado(String id) {
        Envio envio = buscar(id);
        if (envio.getEstado() == EstadoEnvio.ENTREGADO) {
            throw new IllegalStateException("el envío " + id + " ya fue entregado");
        }
        envio.setEstado(envio.getEstado().siguiente());
        repositorio.actualizar(envio);
        return notificador.mensaje(envio);
    }

    // Solo se puede cancelar un envío que todavía no salió (REGISTRADO).
    public void cancelar(String id) {
        Envio envio = buscar(id);
        if (envio.getEstado() != EstadoEnvio.REGISTRADO) {
            throw new IllegalStateException("el envío " + id + " ya no se puede cancelar (estado: "
                    + envio.getEstado().etiqueta() + ")");
        }
        repositorio.eliminar(id);
    }

    public EstadoEnvio estadoDe(String id) {
        return buscar(id).getEstado();
    }

    private Envio buscar(String id) {
        return repositorio.buscarPorId(id)
                .orElseThrow(() -> new IllegalStateException("no existe un envío con el id " + id));
    }

    public void cambiarNotificador(NotificadorEnvio nuevo) {
        this.notificador = nuevo;
    }

    public NotificadorEnvio getNotificador() {
        return notificador;
    }
}
