package com.usil.envios.strategy;

import com.usil.envios.model.Envio;

public class NotificadorCorreo implements NotificadorEnvio {

    @Override
    public String mensaje(Envio envio) {
        return "[CORREO] Para: " + envio.getDestinatario() + " | Envío " + envio.getId()
                + " | Estado: " + envio.getEstado().etiqueta();
    }

    @Override
    public String getNombre() {
        return "Correo";
    }
}
