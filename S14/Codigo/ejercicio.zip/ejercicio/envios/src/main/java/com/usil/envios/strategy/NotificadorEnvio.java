package com.usil.envios.strategy;

import com.usil.envios.model.Envio;

// Patrón Strategy: cada canal arma el mensaje para el destinatario a su manera.
public interface NotificadorEnvio {

    String mensaje(Envio envio);

    String getNombre();
}
