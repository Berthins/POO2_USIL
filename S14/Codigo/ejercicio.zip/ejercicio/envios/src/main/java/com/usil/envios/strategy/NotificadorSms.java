package com.usil.envios.strategy;

import com.usil.envios.model.Envio;

public class NotificadorSms implements NotificadorEnvio {

    @Override
    public String mensaje(Envio envio) {
        return "[SMS] " + envio.getDestinatario() + ": su envío " + envio.getId()
                + " está " + envio.getEstado().etiqueta();
    }

    @Override
    public String getNombre() {
        return "SMS";
    }
}
