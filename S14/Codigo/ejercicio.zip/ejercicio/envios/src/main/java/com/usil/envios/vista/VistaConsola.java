package com.usil.envios.vista;

import com.usil.envios.controller.EnvioController;
import com.usil.envios.model.Envio;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class VistaConsola {

    private final EnvioController controller;
    private final Scanner entrada = new Scanner(System.in, StandardCharsets.UTF_8);
    // Si la entrada viene de un archivo, se repite lo leído para que se vea como en la consola.
    private final boolean eco = System.console() == null;

    public VistaConsola(EnvioController controller) {
        this.controller = controller;
    }

    public void iniciar() {
        int opcion = -1;
        try {
            while (opcion != 0) {
                mostrarMenu();
                opcion = leerEntero("Elija una opción: ");
                switch (opcion) {
                    case 1 -> registrarEnvio();
                    case 2 -> verEnvios();
                    case 3 -> avanzarEstado();
                    case 4 -> cancelarEnvio();
                    case 5 -> cambiarCanal();
                    case 6 -> verPendientesMasPesados();
                    case 0 -> System.out.println("Gracias por usar EnvíoExpress.");
                    default -> System.out.println("Opción inválida.");
                }
                if (opcion != 0) {
                    System.out.println();
                }
            }
        } catch (NoSuchElementException e) {
            System.out.println(); // se acabó la entrada
        }
    }

    private void mostrarMenu() {
        System.out.println("===== ENVIOEXPRESS - GESTOR DE ENVÍOS =====");
        System.out.println("1. Registrar envío");
        System.out.println("2. Ver envíos registrados");
        System.out.println("3. Avanzar estado de un envío");
        System.out.println("4. Cancelar un envío");
        System.out.println("5. Cambiar canal de notificación");
        System.out.println("6. Ver pendientes más pesados");
        System.out.println("0. Salir");
    }

    private void registrarEnvio() {
        System.out.println("--- REGISTRAR ENVÍO ---");
        String id = leerTexto("ID del envío: ");
        String destinatario = leerTexto("Destinatario: ");
        double peso = leerNumero("Peso (kg): ");
        String destino = leerTexto("Destino: ");
        String descripcion = leerTexto("Descripción: ");
        try {
            String notificacion = controller.registrarEnvio(id, destinatario, peso, destino, descripcion);
            System.out.println("Notificación enviada: " + notificacion);
            System.out.println("Envío registrado correctamente.");
        } catch (IllegalStateException e) {
            mostrarError(e);
        }
    }

    private void verEnvios() {
        System.out.println("--- ENVÍOS REGISTRADOS ---");
        List<Envio> envios = controller.listarEnvios();
        int numero = 1;
        for (Envio e : envios) {
            System.out.println(numero + ". " + e.getId() + " | " + e.getDestinatario() + " | "
                    + e.getDestino() + " | " + kg(e.getPeso()) + " | " + e.getEstado().etiqueta());
            numero++;
        }
        System.out.println("Total de envíos: " + envios.size());
        System.out.println("Entregados: " + controller.contarEntregados());
    }

    private void avanzarEstado() {
        System.out.println("--- AVANZAR ESTADO DE UN ENVÍO ---");
        String id = leerTexto("ID del envío: ");
        try {
            String notificacion = controller.avanzarEstado(id);
            System.out.println("Notificación enviada: " + notificacion);
            System.out.println("Envío " + id + " ahora está " + controller.estadoDe(id).etiqueta() + ".");
        } catch (IllegalStateException e) {
            mostrarError(e);
        }
    }

    private void cancelarEnvio() {
        System.out.println("--- CANCELAR ENVÍO ---");
        String id = leerTexto("ID del envío: ");
        try {
            controller.cancelarEnvio(id);
            System.out.println("Envío " + id + " cancelado correctamente.");
        } catch (IllegalStateException e) {
            mostrarError(e);
        }
    }

    private void cambiarCanal() {
        System.out.println("--- CAMBIAR CANAL DE NOTIFICACIÓN ---");
        System.out.println("1. Correo");
        System.out.println("2. SMS");
        int eleccion = leerEntero("Elija: ");
        try {
            controller.cambiarCanal(eleccion);
            System.out.println("Canal activo: " + controller.nombreCanal());
        } catch (IllegalStateException e) {
            mostrarError(e);
        }
    }

    private void verPendientesMasPesados() {
        System.out.println("--- PENDIENTES MÁS PESADOS (TOP 2) ---");
        controller.mostrarPendientesMasPesados(2);
    }

    // ---------- utilidades ----------

    private String leerTexto(String mensaje) {
        System.out.print(mensaje);
        String texto = entrada.nextLine().trim();
        if (eco) {
            System.out.println(texto);
        }
        return texto;
    }

    private int leerEntero(String mensaje) {
        try {
            return Integer.parseInt(leerTexto(mensaje));
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private double leerNumero(String mensaje) {
        try {
            return Double.parseDouble(leerTexto(mensaje));
        } catch (NumberFormatException e) {
            return 0; // un valor no numérico se rechaza como peso inválido
        }
    }

    private String kg(double valor) {
        return String.format(Locale.US, "%.2f kg", valor);
    }

    private void mostrarError(IllegalStateException e) {
        System.out.println("ERROR: " + e.getMessage() + ".");
    }
}
