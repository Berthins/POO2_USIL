package com.usil;

import com.usil.controller.ControladorAlquiler;
import com.usil.service.ServicioAlquiler;
import com.usil.view.VistaAlquiler;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class Principal {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ex) {
                // se usa el aspecto por defecto de Swing
            }
            new ControladorAlquiler(new VistaAlquiler(), new ServicioAlquiler()).iniciar();
        });
    }
}
