package com.usil.controller;

import com.usil.model.TipoCliente;
import com.usil.service.ServicioAlquiler;
import com.usil.view.VistaAlquiler;
import java.util.Arrays;

public class ControladorAlquiler {

    private VistaAlquiler vista;
    private ServicioAlquiler servicio;

    public ControladorAlquiler(VistaAlquiler vista, ServicioAlquiler servicio) {
        this.vista = vista;
        this.servicio = servicio;

        // El combo se llena con los valores del enum usando streams.
        Arrays.stream(TipoCliente.values()).forEach(e -> vista.getCmbCliente().addItem(e.name()));

        vista.getBtnCalcular().addActionListener(e -> calcular());
    }

    public void iniciar() {
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
    }

    private void calcular() {
        try {
            TipoCliente tipo = TipoCliente.values()[vista.getCmbCliente().getSelectedIndex()];
            int dias = Integer.parseInt(vista.getTxtDias().getText().trim());
            double precioBase = Double.parseDouble(vista.getTxtPrecioBase().getText().trim());
            if (dias <= 0 || precioBase <= 0) {
                vista.mostrarError("Los valores deben ser mayores que 0.");
                return;
            }
            double total = servicio.calcular(tipo, dias, precioBase);
            vista.getLblResultado().setText(String.format("Total a pagar: S/ %.2f", total));
        } catch (NumberFormatException ex) {
            vista.mostrarError("Ingrese números válidos.");
        }
    }
}
