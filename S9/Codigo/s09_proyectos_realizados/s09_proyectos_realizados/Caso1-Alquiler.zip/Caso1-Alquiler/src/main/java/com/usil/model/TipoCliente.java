package com.usil.model;

public enum TipoCliente {
    REGULAR, CORPORATIVO, PREMIUM
}
