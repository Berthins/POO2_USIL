package com.usil.service;

import com.usil.model.TipoCliente;
import com.usil.strategy.Alquiler;
import com.usil.strategy.AlquilerCorporativo;
import com.usil.strategy.AlquilerPremium;
import com.usil.strategy.AlquilerRegular;
import com.usil.strategy.AlquilerVehiculo;

public class ServicioAlquiler {

    private AlquilerVehiculo alquilerVehiculo = new AlquilerVehiculo();

    public double calcular(TipoCliente tipoCliente, int dias, double precioBase) {
        Alquiler estrategia = switch (tipoCliente) {
            case REGULAR -> new AlquilerRegular();
            case CORPORATIVO -> new AlquilerCorporativo();
            case PREMIUM -> new AlquilerPremium();
        };
        alquilerVehiculo.setEstrategia(estrategia);
        return alquilerVehiculo.calcularTotal(dias, precioBase);
    }
}
