package com.usil.strategy;

public interface Alquiler {

    double calcularPrecio(int dias, double precioBase);
}
