package com.usil.strategy;

/** Cliente corporativo: 15% de descuento. */
public class AlquilerCorporativo implements Alquiler {

    @Override
    public double calcularPrecio(int dias, double precioBase) {
        return dias * precioBase * 0.85;
    }
}
