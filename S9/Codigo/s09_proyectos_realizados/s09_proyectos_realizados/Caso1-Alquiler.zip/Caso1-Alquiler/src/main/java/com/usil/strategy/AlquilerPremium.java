package com.usil.strategy;

/** Cliente premium: 25% de descuento. */
public class AlquilerPremium implements Alquiler {

    @Override
    public double calcularPrecio(int dias, double precioBase) {
        return dias * precioBase * 0.75;
    }
}
