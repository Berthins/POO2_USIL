package com.usil.strategy;

/** Cliente regular: tarifa completa por cada día. */
public class AlquilerRegular implements Alquiler {

    @Override
    public double calcularPrecio(int dias, double precioBase) {
        return dias * precioBase;
    }
}
