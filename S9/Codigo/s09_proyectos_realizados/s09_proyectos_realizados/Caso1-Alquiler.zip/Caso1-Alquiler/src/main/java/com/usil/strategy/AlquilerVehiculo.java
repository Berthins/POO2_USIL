package com.usil.strategy;

/** Contexto: delega el cálculo del precio en la estrategia seleccionada. */
public class AlquilerVehiculo {

    private Alquiler estrategia;

    public void setEstrategia(Alquiler estrategia) {
        this.estrategia = estrategia;
    }

    public double calcularTotal(int dias, double precioBase) {
        return estrategia.calcularPrecio(dias, precioBase);
    }
}
