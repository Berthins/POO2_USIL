package com.usil.view;

import javax.swing.JOptionPane;

public class VistaAlquiler extends javax.swing.JFrame {

    public VistaAlquiler() {
        initComponents();
        setSize(950, 160);
    }

    public void mostrarError(String message) {
        JOptionPane.showMessageDialog(this, message, "Datos no válidos", JOptionPane.WARNING_MESSAGE);
    }

    public javax.swing.JComboBox<String> getCmbCliente() {
        return cmbCliente;
    }

    public javax.swing.JTextField getTxtDias() {
        return txtDias;
    }

    public javax.swing.JTextField getTxtPrecioBase() {
        return txtPrecioBase;
    }

    public javax.swing.JButton getBtnCalcular() {
        return btnCalcular;
    }

    public javax.swing.JLabel getLblResultado() {
        return lblResultado;
    }

    /** Inicializa los componentes del formulario. No modificar: lo regenera el editor de NetBeans (pestaña Diseño). */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlFormulario = new javax.swing.JPanel();
        lblCliente = new javax.swing.JLabel();
        cmbCliente = new javax.swing.JComboBox<>();
        lblDias = new javax.swing.JLabel();
        txtDias = new javax.swing.JTextField();
        lblPrecioBase = new javax.swing.JLabel();
        txtPrecioBase = new javax.swing.JTextField();
        btnCalcular = new javax.swing.JButton();
        lblResultado = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Caso 1 - Alquiler de vehículos");

        lblCliente.setText("Cliente:");
        pnlFormulario.add(lblCliente);

        cmbCliente.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { }));
        pnlFormulario.add(cmbCliente);

        lblDias.setText("Días:");
        pnlFormulario.add(lblDias);

        txtDias.setColumns(5);
        pnlFormulario.add(txtDias);

        lblPrecioBase.setText("Precio base por día:");
        pnlFormulario.add(lblPrecioBase);

        txtPrecioBase.setColumns(7);
        pnlFormulario.add(txtPrecioBase);

        btnCalcular.setText("Calcular");
        pnlFormulario.add(btnCalcular);

        lblResultado.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblResultado.setText(" ");

        getContentPane().add(pnlFormulario, java.awt.BorderLayout.NORTH);
        getContentPane().add(lblResultado, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCalcular;
    private javax.swing.JComboBox<String> cmbCliente;
    private javax.swing.JLabel lblCliente;
    private javax.swing.JLabel lblDias;
    private javax.swing.JLabel lblPrecioBase;
    private javax.swing.JLabel lblResultado;
    private javax.swing.JPanel pnlFormulario;
    private javax.swing.JTextField txtDias;
    private javax.swing.JTextField txtPrecioBase;
    // End of variables declaration//GEN-END:variables
}
