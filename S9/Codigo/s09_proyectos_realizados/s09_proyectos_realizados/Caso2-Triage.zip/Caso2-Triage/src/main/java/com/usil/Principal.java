package com.usil;

import com.usil.controller.ControladorTriaje;
import com.usil.service.ServicioTriaje;
import com.usil.view.VistaTriaje;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class Principal {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ex) {
                // se usa el aspecto por defecto de Swing
            }
            new ControladorTriaje(new VistaTriaje(), new ServicioTriaje()).iniciar();
        });
    }
}
