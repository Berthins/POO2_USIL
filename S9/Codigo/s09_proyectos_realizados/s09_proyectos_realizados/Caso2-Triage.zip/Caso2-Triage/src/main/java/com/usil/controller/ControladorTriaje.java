package com.usil.controller;

import com.usil.model.Departamento;
import com.usil.model.Paciente;
import com.usil.service.ServicioTriaje;
import com.usil.view.VistaTriaje;
import java.util.Arrays;

public class ControladorTriaje {

    private VistaTriaje vista;
    private ServicioTriaje servicio;

    public ControladorTriaje(VistaTriaje vista, ServicioTriaje servicio) {
        this.vista = vista;
        this.servicio = servicio;

        // El combo se llena con los valores del enum usando streams.
        Arrays.stream(Departamento.values()).forEach(e -> vista.getCmbDepartamento().addItem(e.name()));

        vista.getBtnEvaluar().addActionListener(e -> evaluar());
    }

    public void iniciar() {
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
    }

    private void evaluar() {
        try {
            String nombre = vista.getTxtPaciente().getText().trim();
            int edad = Integer.parseInt(vista.getTxtEdad().getText().trim());
            int dolor = Integer.parseInt(vista.getTxtDolor().getText().trim());
            if (nombre.isEmpty() || edad < 0 || dolor < 0 || dolor > 10) {
                vista.mostrarError("Ingrese el nombre, una edad válida y un dolor entre 0 y 10.");
                return;
            }
            Departamento departamento = Departamento.values()[vista.getCmbDepartamento().getSelectedIndex()];
            int prioridad = servicio.evaluar(new Paciente(nombre, edad, dolor), departamento);
            vista.getLblResultado().setText(nombre + " - Prioridad " + prioridad + " (1 = la más urgente)");
        } catch (NumberFormatException ex) {
            vista.mostrarError("Edad y dolor deben ser números enteros.");
        }
    }
}
