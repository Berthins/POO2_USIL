package com.usil.model;

public enum Departamento {
    CARDIOLOGIA, TRAUMA, PEDIATRIA
}
