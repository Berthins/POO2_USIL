package com.usil.model;

public class Paciente {

    private String nombre;
    private int edad;
    private int nivelDolor;

    public Paciente(String nombre, int edad, int nivelDolor) {
        this.nombre = nombre;
        this.edad = edad;
        this.nivelDolor = nivelDolor;
    }

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public int getNivelDolor() {
        return nivelDolor;
    }
}
