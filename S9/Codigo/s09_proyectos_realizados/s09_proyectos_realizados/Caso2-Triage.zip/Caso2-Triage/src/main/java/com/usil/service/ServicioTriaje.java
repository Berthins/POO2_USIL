package com.usil.service;

import com.usil.model.Departamento;
import com.usil.model.Paciente;
import com.usil.strategy.EvaluadorTriaje;
import com.usil.strategy.Triaje;
import com.usil.strategy.TriajeCardiologia;
import com.usil.strategy.TriajePediatria;
import com.usil.strategy.TriajeTrauma;

public class ServicioTriaje {

    private EvaluadorTriaje evaluador = new EvaluadorTriaje();

    public int evaluar(Paciente paciente, Departamento departamento) {
        Triaje estrategia = switch (departamento) {
            case CARDIOLOGIA -> new TriajeCardiologia();
            case TRAUMA -> new TriajeTrauma();
            case PEDIATRIA -> new TriajePediatria();
        };
        evaluador.setEstrategia(estrategia);
        return evaluador.evaluar(paciente);
    }
}
