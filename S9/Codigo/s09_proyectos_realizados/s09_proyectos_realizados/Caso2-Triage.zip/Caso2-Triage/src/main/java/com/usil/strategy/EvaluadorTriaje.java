package com.usil.strategy;

import com.usil.model.Paciente;

/** Contexto: evalúa al paciente con la estrategia del departamento que lo atiende. */
public class EvaluadorTriaje {

    private Triaje estrategia;

    public void setEstrategia(Triaje estrategia) {
        this.estrategia = estrategia;
    }

    public int evaluar(Paciente paciente) {
        return estrategia.evaluar(paciente);
    }
}
