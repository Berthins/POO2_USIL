package com.usil.strategy;

import com.usil.model.Paciente;

/** Devuelve la prioridad: 1 es la más urgente. */
public interface Triaje {

    int evaluar(Paciente paciente);
}
