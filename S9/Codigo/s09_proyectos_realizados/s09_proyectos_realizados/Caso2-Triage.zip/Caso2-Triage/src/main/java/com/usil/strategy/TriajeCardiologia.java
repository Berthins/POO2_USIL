package com.usil.strategy;

import com.usil.model.Paciente;

public class TriajeCardiologia implements Triaje {

    @Override
    public int evaluar(Paciente paciente) {
        if (paciente.getNivelDolor() >= 8) {
            return 1;
        }
        return paciente.getNivelDolor() >= 5 ? 2 : 3;
    }
}
