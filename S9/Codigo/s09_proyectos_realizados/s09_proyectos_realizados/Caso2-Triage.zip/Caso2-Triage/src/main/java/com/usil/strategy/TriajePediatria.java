package com.usil.strategy;

import com.usil.model.Paciente;

/** Los menores de 2 años siempre tienen prioridad 1. */
public class TriajePediatria implements Triaje {

    @Override
    public int evaluar(Paciente paciente) {
        if (paciente.getEdad() < 2) {
            return 1;
        }
        return paciente.getNivelDolor() >= 7 ? 2 : 3;
    }
}
