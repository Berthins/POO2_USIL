package com.usil.strategy;

import com.usil.model.Paciente;

public class TriajeTrauma implements Triaje {

    @Override
    public int evaluar(Paciente paciente) {
        if (paciente.getNivelDolor() >= 9) {
            return 1;
        }
        if (paciente.getNivelDolor() >= 7) {
            return 2;
        }
        return paciente.getNivelDolor() >= 4 ? 3 : 4;
    }
}
