package com.usil.view;

import javax.swing.JOptionPane;

public class VistaTriaje extends javax.swing.JFrame {

    public VistaTriaje() {
        initComponents();
        setSize(950, 160);
    }

    public void mostrarError(String message) {
        JOptionPane.showMessageDialog(this, message, "Datos no válidos", JOptionPane.WARNING_MESSAGE);
    }

    public javax.swing.JTextField getTxtPaciente() {
        return txtPaciente;
    }

    public javax.swing.JTextField getTxtEdad() {
        return txtEdad;
    }

    public javax.swing.JTextField getTxtDolor() {
        return txtDolor;
    }

    public javax.swing.JComboBox<String> getCmbDepartamento() {
        return cmbDepartamento;
    }

    public javax.swing.JButton getBtnEvaluar() {
        return btnEvaluar;
    }

    public javax.swing.JLabel getLblResultado() {
        return lblResultado;
    }

    /** Inicializa los componentes del formulario. No modificar: lo regenera el editor de NetBeans (pestaña Diseño). */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlFormulario = new javax.swing.JPanel();
        lblPaciente = new javax.swing.JLabel();
        txtPaciente = new javax.swing.JTextField();
        lblEdad = new javax.swing.JLabel();
        txtEdad = new javax.swing.JTextField();
        lblDolor = new javax.swing.JLabel();
        txtDolor = new javax.swing.JTextField();
        lblDepartamento = new javax.swing.JLabel();
        cmbDepartamento = new javax.swing.JComboBox<>();
        btnEvaluar = new javax.swing.JButton();
        lblResultado = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Caso 2 - Triage hospitalario");

        lblPaciente.setText("Paciente:");
        pnlFormulario.add(lblPaciente);

        txtPaciente.setColumns(12);
        pnlFormulario.add(txtPaciente);

        lblEdad.setText("Edad:");
        pnlFormulario.add(lblEdad);

        txtEdad.setColumns(4);
        pnlFormulario.add(txtEdad);

        lblDolor.setText("Dolor (0-10):");
        pnlFormulario.add(lblDolor);

        txtDolor.setColumns(3);
        pnlFormulario.add(txtDolor);

        lblDepartamento.setText("Departamento:");
        pnlFormulario.add(lblDepartamento);

        cmbDepartamento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { }));
        pnlFormulario.add(cmbDepartamento);

        btnEvaluar.setText("Evaluar");
        pnlFormulario.add(btnEvaluar);

        lblResultado.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblResultado.setText(" ");

        getContentPane().add(pnlFormulario, java.awt.BorderLayout.NORTH);
        getContentPane().add(lblResultado, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEvaluar;
    private javax.swing.JComboBox<String> cmbDepartamento;
    private javax.swing.JLabel lblDepartamento;
    private javax.swing.JLabel lblDolor;
    private javax.swing.JLabel lblEdad;
    private javax.swing.JLabel lblPaciente;
    private javax.swing.JLabel lblResultado;
    private javax.swing.JPanel pnlFormulario;
    private javax.swing.JTextField txtDolor;
    private javax.swing.JTextField txtEdad;
    private javax.swing.JTextField txtPaciente;
    // End of variables declaration//GEN-END:variables
}
