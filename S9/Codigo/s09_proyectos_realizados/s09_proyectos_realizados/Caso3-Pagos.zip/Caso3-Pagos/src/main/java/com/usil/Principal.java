package com.usil;

import com.usil.controller.ControladorPago;
import com.usil.service.ServicioPago;
import com.usil.view.VistaPago;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class Principal {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ex) {
                // se usa el aspecto por defecto de Swing
            }
            new ControladorPago(new VistaPago(), new ServicioPago()).iniciar();
        });
    }
}
