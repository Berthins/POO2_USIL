package com.usil.controller;

import com.usil.model.MetodoPago;
import com.usil.service.ServicioPago;
import com.usil.view.VistaPago;
import java.util.Arrays;

public class ControladorPago {

    private VistaPago vista;
    private ServicioPago servicio;

    public ControladorPago(VistaPago vista, ServicioPago servicio) {
        this.vista = vista;
        this.servicio = servicio;

        // El combo se llena con los valores del enum usando streams.
        Arrays.stream(MetodoPago.values()).forEach(e -> vista.getCmbMetodo().addItem(e.name()));

        vista.getBtnPagar().addActionListener(e -> pagar());
    }

    public void iniciar() {
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
    }

    private void pagar() {
        try {
            MetodoPago metodo = MetodoPago.values()[vista.getCmbMetodo().getSelectedIndex()];
            double monto = Double.parseDouble(vista.getTxtMonto().getText().trim());
            if (monto <= 0) {
                vista.mostrarError("El monto debe ser mayor que 0.");
                return;
            }
            vista.getLblResultado().setText(servicio.pagar(metodo, monto));
        } catch (NumberFormatException ex) {
            vista.mostrarError("Ingrese un monto válido.");
        }
    }
}
