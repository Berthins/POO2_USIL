package com.usil.model;

public enum MetodoPago {
    TARJETA, PAYPAL, CRIPTO, BILLETERA
}
