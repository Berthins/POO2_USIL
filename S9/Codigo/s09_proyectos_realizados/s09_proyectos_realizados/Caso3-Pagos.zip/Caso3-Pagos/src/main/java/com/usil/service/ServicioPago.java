package com.usil.service;

import com.usil.model.MetodoPago;
import com.usil.strategy.Pago;
import com.usil.strategy.PagoBilletera;
import com.usil.strategy.PagoCripto;
import com.usil.strategy.PagoPayPal;
import com.usil.strategy.PagoTarjeta;
import com.usil.strategy.ProcesadorPago;

public class ServicioPago {

    private ProcesadorPago procesador = new ProcesadorPago();

    public String pagar(MetodoPago metodo, double monto) {
        Pago estrategia = switch (metodo) {
            case TARJETA -> new PagoTarjeta();
            case PAYPAL -> new PagoPayPal();
            case CRIPTO -> new PagoCripto();
            case BILLETERA -> new PagoBilletera();
        };
        procesador.setEstrategia(estrategia);
        return procesador.procesar(monto);
    }
}
