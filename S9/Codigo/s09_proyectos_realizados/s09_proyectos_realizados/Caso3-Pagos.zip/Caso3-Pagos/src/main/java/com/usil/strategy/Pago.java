package com.usil.strategy;

public interface Pago {

    String pagar(double monto);
}
