package com.usil.strategy;

public class PagoBilletera implements Pago {

    @Override
    public String pagar(double monto) {
        return "Pago de S/ " + monto + " realizado con billetera móvil.";
    }
}
