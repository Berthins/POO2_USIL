package com.usil.strategy;

public class PagoCripto implements Pago {

    @Override
    public String pagar(double monto) {
        return "Pago de S/ " + monto + " realizado con criptomonedas.";
    }
}
