package com.usil.strategy;

public class PagoPayPal implements Pago {

    @Override
    public String pagar(double monto) {
        return "Pago de S/ " + monto + " realizado con PayPal.";
    }
}
