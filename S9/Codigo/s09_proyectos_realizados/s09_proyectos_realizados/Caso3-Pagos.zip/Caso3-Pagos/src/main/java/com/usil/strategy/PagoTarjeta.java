package com.usil.strategy;

public class PagoTarjeta implements Pago {

    @Override
    public String pagar(double monto) {
        return "Pago de S/ " + monto + " realizado con tarjeta de crédito.";
    }
}
