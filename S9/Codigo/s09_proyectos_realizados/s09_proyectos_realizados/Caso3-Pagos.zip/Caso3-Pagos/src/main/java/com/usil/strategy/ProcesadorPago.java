package com.usil.strategy;

/** Contexto: delega el pago en la estrategia seleccionada. */
public class ProcesadorPago {

    private Pago estrategia;

    public void setEstrategia(Pago estrategia) {
        this.estrategia = estrategia;
    }

    public String procesar(double monto) {
        return estrategia.pagar(monto);
    }
}
