package com.usil.view;

import javax.swing.JOptionPane;

public class VistaPago extends javax.swing.JFrame {

    public VistaPago() {
        initComponents();
        setSize(950, 160);
    }

    public void mostrarError(String message) {
        JOptionPane.showMessageDialog(this, message, "Datos no válidos", JOptionPane.WARNING_MESSAGE);
    }

    public javax.swing.JComboBox<String> getCmbMetodo() {
        return cmbMetodo;
    }

    public javax.swing.JTextField getTxtMonto() {
        return txtMonto;
    }

    public javax.swing.JButton getBtnPagar() {
        return btnPagar;
    }

    public javax.swing.JLabel getLblResultado() {
        return lblResultado;
    }

    /** Inicializa los componentes del formulario. No modificar: lo regenera el editor de NetBeans (pestaña Diseño). */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlFormulario = new javax.swing.JPanel();
        lblMetodo = new javax.swing.JLabel();
        cmbMetodo = new javax.swing.JComboBox<>();
        lblMonto = new javax.swing.JLabel();
        txtMonto = new javax.swing.JTextField();
        btnPagar = new javax.swing.JButton();
        lblResultado = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Caso 3 - Procesador de pagos");

        lblMetodo.setText("Método de pago:");
        pnlFormulario.add(lblMetodo);

        cmbMetodo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { }));
        pnlFormulario.add(cmbMetodo);

        lblMonto.setText("Monto:");
        pnlFormulario.add(lblMonto);

        txtMonto.setColumns(8);
        pnlFormulario.add(txtMonto);

        btnPagar.setText("Pagar");
        pnlFormulario.add(btnPagar);

        lblResultado.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblResultado.setText(" ");

        getContentPane().add(pnlFormulario, java.awt.BorderLayout.NORTH);
        getContentPane().add(lblResultado, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnPagar;
    private javax.swing.JComboBox<String> cmbMetodo;
    private javax.swing.JLabel lblMetodo;
    private javax.swing.JLabel lblMonto;
    private javax.swing.JLabel lblResultado;
    private javax.swing.JPanel pnlFormulario;
    private javax.swing.JTextField txtMonto;
    // End of variables declaration//GEN-END:variables
}
